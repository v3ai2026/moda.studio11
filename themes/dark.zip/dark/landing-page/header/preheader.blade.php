<div
    class="site-preheader flex items-center justify-center px-3 pt-4 text-center text-2xs text-white/70 opacity-0 transition-all duration-500 group-[.page-loaded]/body:opacity-100">
    <p>
        <span class="me-3 bg-gradient-to-r from-gradient-from to-gradient-to to-50% bg-clip-text text-4xs font-semibold uppercase tracking-wide text-transparent">
            {{ __($fSetting->header_title) }}
        </span>
        <span class="opacity-70">
            {{ __($fSetting->header_text) }}
        </span>
    </p>
</div>
