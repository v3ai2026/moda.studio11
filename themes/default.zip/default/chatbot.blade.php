<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >
    <meta
        http-equiv="X-UA-Compatible"
        content="ie=edge"
    >
{{--    <script defer--}}
{{--            src="{{ url('vendor/chatbot/js/external-chatbot.js') }}"--}}
{{--            data-chatbot-uuid="{{ \App\Extensions\Chatbot\System\Models\Chatbot::query()->first()?->uuid }}"--}}
{{--            data-iframe-width="420"--}}
{{--            data-iframe-height="745"--}}
{{--    ></script>--}}

    <script
        defer
        src="https://magicai.test/vendor/chatbot/js/external-chatbot.js"
        data-chatbot-uuid="101f8770-2a45-41cd-a922-9b0041981906"
        data-iframe-width="420"
        data-iframe-height="745"
    ></script>
</head>

<body>

</body>

</html>
