@extends('layout.error')

@section('error_code', '503')
@section('error_title', __('503 Maintenance'))
@section('error_subtitle', __('The system has maintenance! We will back in short time!'))
