@push('script')
	<script src="{{ custom_theme_url('/assets/js/panel/marketplace.js') }}"></script>
@endpush
