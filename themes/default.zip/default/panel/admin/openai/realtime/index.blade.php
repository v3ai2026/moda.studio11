@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Real time chat'))
@section('titlebar_subtitle', __('Manage Built-in Prompts and Templates'))
@section('titlebar_actions', '')
@section('content')
@endsection

@push('script')
@endpush
