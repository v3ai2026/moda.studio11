@livewire('assign-view-credits', ['entities' => $plan->ai_models, 'plan' => $plan])
