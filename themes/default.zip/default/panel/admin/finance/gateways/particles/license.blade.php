<div class="mb-4 w-full rounded-xl bg-red-100 !p-3 text-center text-red-600 dark:bg-orange-600/20 dark:text-orange-200">
    {{ __('To access this page, you should upgrade to Extended License.') }} <a href="{{ route('LaravelInstaller::license.upgrade') }}"><u> {{ __('Upgrade License') }}</u></a>
</div>