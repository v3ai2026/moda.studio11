<x-tabs-trigger
    target="{{ isset($target) ? $target : '' }}"
    style="3"
    label="{{ isset($label) ? $label : '' }}"
    active="{{ isset($active) ? $active : '' }}"
    badge="{{ isset($badge) ? $badge : '' }}"
/>
