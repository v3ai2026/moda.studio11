<x-navbar.item>
    <x-navbar.label title="{{ __(data_get($item, 'label')) }}">
        {{ __(data_get($item, 'label')) }}
    </x-navbar.label>
</x-navbar.item>
