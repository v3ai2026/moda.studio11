<x-navbar.item>
    <x-navbar.divider />
</x-navbar.item>