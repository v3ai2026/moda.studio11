<div class="border-b last:border-b-0">
    {{ $slot }}
</div>
