<x-titlebar layout-wide="{{ isset($layout_wide) ? $layout_wide : '' }}">
</x-titlebar>
