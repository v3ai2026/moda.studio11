@extends('layout.app')

<svg
    style="display: none"
    width="21"
    height="15"
    viewBox="0 0 21 15"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
>
    <path
        id="arrow-icon"
        fill="currentColor"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M19.3889 6.37388C16.68 6.37388 14.2111 3.87274 14.2111 1.12613V0H11.9889V1.12613C11.9889 3.12387 12.8533 4.99774 14.21 6.37388H0.5V8.62613H14.21C12.8533 10.0023 11.9889 11.8761 11.9889 13.8739V15H14.2111V13.8739C14.2111 11.1273 16.68 8.62613 19.3889 8.62613H20.5V6.37388H19.3889Z"
    />
</svg>
