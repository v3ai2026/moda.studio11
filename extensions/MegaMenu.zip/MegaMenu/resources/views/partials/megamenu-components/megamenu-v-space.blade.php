@php
    $space = $mega_menu_item['space'] ?? 0;
@endphp

<div class="lqd-megamenu-v-space">
    <div
        class="lqd-megamenu-v-space-inner"
        style="height: {{ $space }}px;"
    ></div>
</div>
