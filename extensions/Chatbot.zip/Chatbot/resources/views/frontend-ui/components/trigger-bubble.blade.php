<div class="lqd-ext-chatbot-trigger-bubble">
    <p x-text="activeChatbot.bubble_message"></p>
</div>
