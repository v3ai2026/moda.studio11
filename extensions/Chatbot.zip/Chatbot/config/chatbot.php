<?php

return [
    'version' => 1.0,
    'avatars' => [
        'avatar-1.png',
        'avatar-2.png',
        'avatar-3.png',
        'avatar-4.png',
        'avatar-5.png',
    ],
    'notification_enabled' => env('CHATBOT_NOTIFICATION_ENABLED', true),
];
