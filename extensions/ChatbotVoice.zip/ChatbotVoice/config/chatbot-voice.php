<?php

return [
    'version' => 1.0,
    'avatars' => [
        'avatar-1.png',
    ],
];
