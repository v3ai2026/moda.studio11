<?php

return [
    'name'    => 'Messenger Channel',
    'version' => 1.0,
];
