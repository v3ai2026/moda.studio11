<?php

return [
    'name'    => 'Telegram Channel',
    'version' => 1.0,
];
