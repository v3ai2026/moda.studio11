<?php

return [
    'creatify_api_id'  => '',
    'creatify_api_key' => '',

    'topview_api_id'  => '',
    'topview_api_key' => '',
];
