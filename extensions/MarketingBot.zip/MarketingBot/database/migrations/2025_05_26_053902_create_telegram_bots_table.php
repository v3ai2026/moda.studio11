<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (! Schema::hasTable('ext_telegram_bots')) {
            Schema::create('ext_telegram_bots', function (Blueprint $table) {
                $table->id();
                $table->bigInteger('user_id')->nullable();
                $table->string('access_token')->nullable();
                $table->boolean('is_connected')->default(false);
                $table->boolean('webhook_verified')->default(false);
                $table->bigInteger('bot_id')->nullable();
                $table->string('name')->nullable();
                $table->string('username')->nullable();
                $table->json('scopes')->nullable();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ext_telegram_bots');
    }
};
