<?php

return [
    'version'              => 1.0,
    'notification_enabled' => env('MARKETING_BOT_NOTIFICATION_ENABLED', true),
];
