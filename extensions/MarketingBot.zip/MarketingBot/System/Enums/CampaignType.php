<?php

namespace App\Extensions\MarketingBot\System\Enums;

enum CampaignType: string
{
    case telegram = 'telegram';
    case whatsapp = 'whatsapp';
}
