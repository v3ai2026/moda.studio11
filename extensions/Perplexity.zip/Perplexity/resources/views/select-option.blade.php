<option
	value="perplexity"
	{{ setting("default_realtime") === "perplexity" ? 'selected' : '' }}
>
	{{ __('Perplexity') }}</option>
