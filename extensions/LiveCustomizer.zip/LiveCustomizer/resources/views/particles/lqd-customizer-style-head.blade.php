<style id="lqd-customizer-style">
	{!! setting(setting('dash_theme') . '_' . 'live_customizer') !!}
</style>
